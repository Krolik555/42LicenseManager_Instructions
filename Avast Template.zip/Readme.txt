This .zip contains the Avast import notes as well as the .csv import template for Avast Business Cloud Care.

To get your Avast data for import:
1. Sign into your Avast Business Cloud Care account.
2. Go to "Reports"
3. Under "Security" click "Subscription Summary"
4. Click "Generate Report". The default settings should be fine.
You can import the file it downloads without any modifications.